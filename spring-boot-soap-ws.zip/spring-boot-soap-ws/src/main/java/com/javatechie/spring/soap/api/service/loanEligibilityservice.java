package com.javatechie.spring.soap.api.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.javatechie.spring.soap.api.loaneligibility.Acknowledgement;
import com.javatechie.spring.soap.api.loaneligibility.CustomerRequest;

@Service
public class loanEligibilityservice {
	
	public Acknowledgement checkloanEligibility(CustomerRequest request){
		
		Acknowledgement acknowledgement = new Acknowledgement();
		List<String> mismatchcriterialist = acknowledgement.getCriteriamismatch();
		
		
		if(!(request.getAge()>30 && request.getAge()<=60)){
			mismatchcriterialist.add("tiskjaldaj");
			
		}
		if(!(request.getYearincome()>200000)){
			mismatchcriterialist.add("tiskjaldaj");
			
		}
		if(!(request.getCibilsocer()>500)){
			mismatchcriterialist.add("tiskjaldaj");
			
		}
		
		if(mismatchcriterialist.size()>0){
			acknowledgement.setApprovementtype(0);
			acknowledgement.setIsElisgible(false);
			
		}else{
			acknowledgement.setApprovementtype(500000);
			acknowledgement.setIsElisgible(true);
			mismatchcriterialist.clear();
		}
		return acknowledgement;
	}

}
